RegisterServerEvent("m-multichar-server-LoadPlayer")
AddEventHandler("m-multichar-server-LoadPlayer",function(data)
    src = source
    Wait(200)


    local _, _, number = string.find(data.identifier, Config.Prefix .. "(%d+)")
    TriggerClientEvent("m-multichar-server-closeNui", src)
    SetPlayerRoutingBucket(src, Config.DefaultBucket)
    TriggerEvent('esx:onPlayerJoined', src, Config.Prefix..number, nil)
    LoadPlayer(src)
    CODEM.PlayTime.PlayTimeLogin(data.identifier)


end)


Citizen.CreateThread(function ()
    src = source
    while not Core do 
        Citizen.Wait(10)
    end
    Core.RegisterServerCallback('m-multichar-server-GetCharacters', function(src, cb)
        identifier = Config.Prefix..'%:'..Core.GetIdentifier(src)
        chars = {}
        local result = ExecuteSql('SELECT * FROM users WHERE identifier LIKE  "%'..identifier..'%"')
        for i = 1, (#result), 1 do
            result[i].identifier = result[i].identifier
            result[i].accounts = json.decode(result[i].accounts)

            result[i].phone_number = result[i].phone_number or Config.Phone_number -- default phone number
		--	result[i].phone_number = json.decode(result[i].charinfo.phone) -- quasar phone

            result[i].nationality = result[i].nationality or Config.Nationality
            result[i].extras = GetExtras(result[i].identifier,result[i].group)
            result[i].totalPlayedTime = CODEM.PlayTime.GetTotalPlayTime(result[i].identifier)
            table.insert(chars, result[i])
        end
        cb(chars)
        steamname = GetPlayerName(src)
        steampp = GetSteamPP(src)
        TriggerClientEvent("m-multichar-set-steam-info",src, steamname, steampp, src)
    end)  
    
    Core.RegisterServerCallback("m-multichar:server:getSkin", function(source, cb, cid)
         local src = source
         local result = ExecuteSql('SELECT skin FROM users WHERE identifier = "'..cid..'"')
         if result[1] ~= nil then
             cb(result[1].skin)
         else
             cb(nil)
         end
     end)
end)

RegisterServerEvent("m-multichar-server-CreateChar")
AddEventHandler("m-multichar-server-CreateChar",function(data)
    src = source
    SetPlayerRoutingBucket(src, Config.DefaultBucket)
    TriggerEvent('esx:onPlayerJoined', src, Config.Prefix..data.cid, data)
    LoadPlayer(src)
    local ply = Core.GetPlayerFromId(src)
    identifier = ply.identifier
    CODEM.PlayTime.PlayTimeLogin(identifier)
    TriggerClientEvent("m-multichar-server-closeNui", src)
end)

GetExtras = function(id,group)
	local status = GlobalState.PlayerStates or {}
	local admin = group ~= nil and group ~= 'user'
	if admin then if not status[id] then status[id] = {} end status[id]['admin'] = true end
	return status[id] or {}
end

GlobalState.PlayerStates = json.decode(GetResourceKvpString("char_status") or '[]') or {}

RegisterServerEvent("m-multichar-server-StarterItems")
AddEventHandler("m-multichar-server-StarterItems",function()
    local xPlayer = Core.GetPlayerFromId(src)
    local starter = json.decode(GetResourceKvpString("starteritems") or '[]') or {} 
    if starter[xPlayer.identifier] then return end
    for _, v in pairs(Config.ESXStarterItem) do
        if Config.CodemInventory then
            exports["codem-inventory"]:AddItem(src, v.item, v.amount, false)
        else
            xPlayer.addInventoryItem(v.item,v.amount)
        end
    end
    starter[xPlayer.identifier] = true
    SetResourceKvp('starteritems',json.encode(starter))
end)

RegisterServerEvent('m-multichar:server:deleteCharacter')
AddEventHandler('m-multichar:server:deleteCharacter', function(charid)
    local src = source

    if Config.CanDelete and type(charid) == 'number' and string.len(charid) <= 2 then
		local identifier = ('%s%s:%s'):format(Config.Prefix, charid, Core.GetIdentifier(source))
		local query = 'DELETE FROM %s WHERE %s = ?'
		local queries = {}
		local count = 0

		for table, column in pairs(Config.DeleteTable) do
			count += 1
			queries[count] = {query = query:format(table, column), values = {identifier}}
		end

		MySQL.transaction(queries, function(result)
            if result then
                print(('[^2INFO^7] Player ^5%s %s^7 has deleted a character ^5(%s)^7'):format(GetPlayerName(src), src, identifier))
                Wait(50)
            else
                error('\n^1Transaction failed while trying to delete ' .. identifier .. '^0')
            end
		end)
	end
end)

LoadPlayer = function(source)
	local src = source
	local ts = 0
	while not Core.GetPlayerFromId(src) and ts < 1000 do ts += 1 Wait(0) end
	local ply = Player(src).state
	local identifier = Core.GetPlayerFromId(src).identifier
	if identifier then
		ply:set('identifier', Core.GetPlayerFromId(src).identifier,true)
	end
	return true
end

Citizen.CreateThread(function()
    while Config == nil or Core == nil do
        Wait(5)
    end
    Core.RegisterCommand(Config.LogoutCDM, 'admin', function(xPlayer, args, showError)
        local source = xPlayer.source
        TriggerEvent("m-multichar-server-Relog", source)
    end, true,
    {
        help = 'LOGOUT Commnad (Admin Only)',
        validate = true,
    })
end)


Citizen.CreateThread(function()
    local resource_name = 'm-multichar-esx'
    local current_version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)
    PerformHttpRequest('https://raw.githubusercontent.com/Aiakos232/versionchecker/main/version.json',
        function(error, result, headers)
            if not result then
                print('^1Version check disabled because github is down.^0')
                return
            end
            local result = json.decode(result)
            if tonumber(result[resource_name]) ~= nil then
                if tonumber(result[resource_name]) > tonumber(current_version) then
                    print('\n')
                    print('^1======================================================================^0')
                    print('^1' .. resource_name ..
                        ' is outdated, new version is available: ' .. result[resource_name] .. '^0')
                    print('^1======================================================================^0')
                    print('\n')
                elseif tonumber(result[resource_name]) == tonumber(current_version) then
                    print('^2' .. resource_name .. ' is up to date! -  ^4 Thanks for choose CodeM ^4 ^0')
                elseif tonumber(result[resource_name]) < tonumber(current_version) then
                    print('^3' .. resource_name .. ' is a higher version than the official version!^0')
                end
            else
                print('^1' .. resource_name .. ' is not in the version database^0')
            end
        end, 'GET')
end)