
fx_version 'cerulean'

author 'yusufkaracolak'
version '1.9'
game 'gta5'

client_scripts {
    'GetCore.lua',
    'config/config.lua',
    'client/client.lua',
    'client/clothes.lua',
}
server_scripts {
    --'@mysql-async/lib/MySQL.lua',
    '@oxmysql/lib/MySQL.lua',
    'GetCore.lua',
    'server/server.lua',
    'server/function.lua',
    'config/config.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/images/*.png',
    'html/images/*.svg',
    'html/fonts/*.OTF',
    'html/fonts/*.otf',
    'html/fonts/*.ttf',
    'html/js/index.js',
    'html/js/*.js',
    'html/click.MP3',

}

escrow_ignore {
	'config/*.lua',
    'client/clothes.lua',
	'GetCore.lua',
    'server/function.lua',


}

lua54 'yes'
dependency '/assetpacks'