
Config = {}


-- es_extened/config.lua
-- Config.Multichar = true
-- make sure it is in the form of

Config.Framework = 'esx' -- ONLY NEW ESX SUPPORTED
Config.Mysql = "oxmysql"  --- mysql-async - oxmysql - ghmattimysql
 -- fivem-appearance -- make sure the illenium-appearance skinchanger script is turned off
Config.Clothes = "default" -- default -- fivem-appearance -- illenium-appearance -- codem-appearance
Config.Prefix = 'char' -- dont changed
Config.CanDelete = true
Config.SpawnSelector = false
Config.Nationality = 'Turkiye' -- if there is no "nationality" in the user table, change here
Config.Phone_number = '000-0000' -- if there is no "phone_number" in the user table, change here
Config.HiddenCoords = vector4(-812.23, 182.54, 76.74, 156.5) -- 156.5 == heading
Config.DefaultPicture = 'https://www.gitbook.com/cdn-cgi/image/width=40,dpr=2,height=40,fit=contain,format=auto/https%3A%2F%2F3253843082-files.gitbook.io%2F~%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMRUfpMzIuVWlJ1CkzDbb%252Ficon%252FD3wjQp0cCyS6MkqdCs1C%252Fimage_2022-09-06_182033969.png%3Falt%3Dmedia%26token%3D662e0ec6-bb96-40d2-87e0-3e74d4061566'
Config.DateFormat = "tr-TR" -- http://www.lingoes.net/en/translator/langcode.htm
Config.DefaultBucket = 0 -- (please don't change it if you don't know)
Config.ServerLogo = "mrp.png"
Config.EnableCamShake = true
Config.CodemInventory = false -- if you use codem inventory, change it to true
Config.LogoutCDM = 'changecharacter'
Config.Slots = {
    [1] = {tebex = false, id = 1},
    [2] = {tebex = false, id = 2},
    [3] = {tebex = false, id = 3},
    [4] = {tebex = false, id = 4},
    [5] = {tebex = true, id = 5},
}

Config.DeleteTable = {users = 'identifier',  owned_vehicles = 'owner', billing = 'identifier'}

Config.Animations = {
    ["unemployed"] = {
        camwiewcoord = {coord = vector3(-830.330, 167.9625, 70.294), rot = -25.0}, 
        car = {coord = vector4(-828.923, 173.1707, 70.511, 200.0), hash = "sultan"}, -- car hash
        Peds = {
            {
                coord = vector4(-829.995, 172.3521, 70.403, 170.0), -- npc coord 170.0 heading
                hash = "g_m_y_ballaorig_01", -- npc hash
                isPlayerPed = false,
                animation = {"missheist_jewelleadinout", "jh_int_outro_loop_a"},
            },
            {
                coord = vector4(-828.049, 170.8139, 70.291, 170.0),
                hash = "mp_m_famdd_01",
                isPlayerPed = false,
                animation = {"amb@world_human_leaning@male@wall@back@foot_up@idle_a", "idle_a"},
            },
            {
                coord = vector4(-829.742, 169.4886, 70.007, 160.0),
                hash = nil,
                isPlayerPed = true, -- this ped have a player clothes
                animation = {"timetable@amanda@ig_2", "ig_2_base_amanda"},
            },
        }
    },
    ["police"] = {
        camwiewcoord = {coord = vector3(497.3135, -987.479, 27.969), rot = 88.0}, 
        car = {coord = vector4(492.0758, -987.542, 27.633, -90.0), hash = "police2"}, -- car hash
        Peds = {
            {
                coord = vector4(489.6207, -985.963, 27.628, -90.0),
                hash = "mp_m_securoguard_01",
                isPlayerPed = false,
                animation = {"missheist_jewelleadinout", "jh_int_outro_loop_a"},
            },
            {
                coord = vector4(489.7647, -989.271, 27.655, -90.0),
                hash = "s_m_m_armoured_02",
                isPlayerPed = false,
                animation = {"amb@world_human_leaning@male@wall@back@foot_up@idle_a", "idle_a"},
            },
            {
                coord = vector4(494.9454, -987.481, 27.434, -90.0),
                hash = nil,
                isPlayerPed = true, -- this ped have a player clothes
                animation = {"timetable@amanda@ig_2", "ig_2_base_amanda"},
            },
        }
    },
    ["ambulance"] = {
        camwiewcoord = {coord = vector3(301.9914, -1439.41, 29.998), rot = 140.0}, 
        car = {coord = vector4(297.3335, -1444.75, 29.860, 0.0), hash = "ambulance"}, -- car hash
        Peds = {
            {
                coord = vector4(297.7074, -1441.08, 29.797, -40.0),
                hash = "s_m_m_doctor_01",
                isPlayerPed = false,
                animation = {"missheist_jewelleadinout", "jh_int_outro_loop_a"},
            },
            {
                coord = vector4(299.7201, -1445.90, 29.804, -40.0),
                hash = "s_m_m_paramedic_01",
                isPlayerPed = false,
                animation = {"amb@world_human_leaning@male@wall@back@foot_up@idle_a", "idle_a"},
            },
            {
                coord = vector4(300.7377, -1440.94, 29.794, -40.0),
                hash = nil,
                isPlayerPed = true, -- this ped have a player clothes
                animation = {"timetable@amanda@ig_2", "ig_2_base_amanda"},
            },
        }
    }
}

Config.ESXStarterItem = {
	[1] = {item = 'water', amount = 2},
	[2] = {item = 'phone', amount = 1},
}

Config.Locales = {
    ["mainTitle"] = "CHARACTER SELECTION",
    -- TEBEX POPUP
    ["tebexPopUpTitle"] = "BUY NEW CHARACTER SLOT",
    ["tebexPopUpButton"] = "OPEN SLOT",
    -- DELETE POPUP
    ["deletePopUpTitle"] = "ARE YOU SURE TO DELETE",
    ["deletePopUpTitle2"] = "THIS CHARACTER ?",
    ["deleteTitle"] = "DELETE CHARACTER",
    -- Global
    ["hello"] = "Hello",
    ["selectchar"] = "Please select a character",
    ["cityAwait"] = "City awaits you!",
    ["createYourNow"] = "Create your character now!",
    ["selected"] = "SELECTED",
    ["noButton"] = "NO",
    ["yesButton"] = "YES",
    ["createNewTitle"] = "CREATE NEW CHARACTER",
    -- Main Page
    ["playButton"] = "PLAY",
    ["playNowText"] = "City awaits you! Play Now!",
    -- -- Current Character Data
    ["statisticsTitle"] = "Character Statistics",
    ["nationalityTitle"] = "NATIONALITY",
    ["numberTitle"] = "NUMBER",
    ["bankTitle"] = "BANK",
    ["cashTitle"] = "CASH",
    ["ageTitle"] = "AGE",
    -- Register Page
    ["registerTitle"] = "CHARACTER REGISTER",
    ["newCharacterTitle"] = "NEW CHARACTER",
    ["registerError"] = "Please fill the blanks correctly!",
    ["nameInput"] = "Name",
    ["surnameInput"] = "Surname",
    ["nationalityInput"] = "Nationality",
    ["birthdateInput"] = "Birthdate",
    ["heightInput"] = "Height",
    ["maleInput"] = "MALE",
    ["femaleInput"] = "FEMALE",
    ["createButton"] = "CREATE",
}

Config.SetSpawnTrigger = function(spawn, isNew, skin)
    TriggerEvent("m-spawnselector:client:display", spawn, isNew, skin) 
end

Config.CloseLoadScreen = function ()
	TriggerEvent('esx:loadingScreenOff')
end

function SecondsToClock(seconds)
    if seconds ~= nil then
        local seconds = tonumber(seconds)

        if seconds <= 0 then
            return "0H 0M PLAYTIME"; -- you can change here //
        else
            hours = string.format("%0.f", math.floor(seconds/3600));
            mins = string.format("%0.f", math.floor(seconds/60 - (hours*60)));
            return hours.."H "..mins.."M PLAYTIME" -- you can change here //
        end
    end
end

-- else is activated when Config.SpawnSelector is false
Config.SetupPlayer = function(coords, isNew) 
	if isNew then
		local playerPed = PlayerPedId()
		FreezeEntityPosition(playerPed, true)
		SetEntityCoordsNoOffset(playerPed, coords.x, coords.y, coords.z, false, false, false, true)
		SetEntityHeading(playerPed, coords.heading)
		FreezeEntityPosition(playerPed, false)
	else
		local playerPed = PlayerPedId()
		FreezeEntityPosition(playerPed, true)
		SetEntityCoordsNoOffset(playerPed, coords.x, coords.y, coords.z, false, false, false, true)
		SetEntityHeading(playerPed, coords.heading)
		FreezeEntityPosition(playerPed, false)
	end
end

Config.ClientNotification = function(message, type, length) -- You can change notification event here
    if Config.Framework == "esx" then
        TriggerEvent("esx:showNotification", message)
    else
        TriggerEvent('QBCore:Notify', message, type, length)
    end
end

Config.ServerNotification = function(source, message, type, length) -- You can change notification event here
    if Config.Framework == "esx" or Config.Framework == 'oldesx' then
        TriggerClientEvent("esx:showNotification",source, message)
    else
        TriggerClientEvent('QBCore:Notify', source, message, type, length)
    end
end

function GetIdentifier(source)
    if Config.Framework == "esx" or Config.Framework == "oldesx" then
        local xPlayer = Core.GetPlayerFromId(tonumber(source))
        if xPlayer then
            return xPlayer.getIdentifier()
        else
            return "0"
        end
    else
        local Player = Core.Functions.GetPlayer(tonumber(source))
        if Player then
            return Player.PlayerData.citizenid
        else
            return "0"
        end
    end
end

function GetName(source)
   if Config.Framework == "esx" or Config.Framework == 'oldesx' then
       local xPlayer = Core.GetPlayerFromId(tonumber(source))
       if xPlayer then
           return xPlayer.getName()
       else
           return "0"
       end
   else
       local Player = Core.Functions.GetPlayer(tonumber(source))
       if Player then
            
           return Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
       else
           return "0"
       end
   end
end

function GetPlayer(source)
    local Player = false
    while Core == nil do
        Citizen.Wait(0)
    end
    if Config.Framework == 'esx' or Config.Framework == 'oldesx' then
        Player = Core.GetPlayerFromId(source)
    else
        Player = Core.Functions.GetPlayer(source)     
    end
    return Player
end

function DeleteVehicle(vehicle)
    while Core == nil do
        Citizen.Wait(0)
    end
    if Config.Framework == "esx" or Config.Framework == "oldesx" then
        Core.Game.DeleteVehicle(vehicle)
    else
        Core.Functions.DeleteVehicle(vehicle)
    end
end

function LoadSkin(skn)
    TriggerEvent('skinchanger:loadSkin', skn)
end

function GetModel(str,othermodel)
    model = nil
    skin = Config.Appearance[Config.Clothes][str or 'm']
    skin.sex = str == "m" and 0 or 1
    if skin.sex == 0 then
        model = `mp_m_freemode_01`
    else
        model = `mp_f_freemode_01`
    end
    return model
end


function SetSkin(ped, skn)
    TriggerEvent('skinchanger:loadSkin', skn)
end

function SkinMenu(sknn)
    TriggerEvent('skinchanger:loadSkin', sknn, function()
        local playerPed = PlayerPedId()
        SetPedAoBlobRendering(playerPed, true)
        ResetEntityAlpha(playerPed)
        SetEntityVisible(playerPed,true)
        TriggerEvent('esx_skin:openSaveableMenu', function()
            TriggerEvent("m-multichar-client-finished")
        end, function()
            TriggerEvent("m-multichar-client-finished")
        end)
    end)
end


-- Default appearance for new characters
Config.Appearance = {
	['illenium-appearance'] = {
		['m'] = {
			tattoos = {
			},
			props = {
			[1] = {
				prop_id = 0,
				texture = -1,
				drawable = -1,
				},
			[2] = {
				prop_id = 1,
				texture = -1,
				drawable = -1,
				},
			[3] = {
				prop_id = 2,
				texture = -1,
				drawable = -1,
				},
			[4] = {
				prop_id = 6,
				texture = -1,
				drawable = -1,
				},
			[5] = {
				prop_id = 7,
				texture = -1,
				drawable = -1,
				},
			},
			model = "mp_m_freemode_01",
			headOverlays = {
			moleAndFreckles = {
				opacity = 0.5,
				color = 0,
				style = 0,
				},
			ageing = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			complexion = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			chestHair = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			beard = {
				opacity = 0,
				color = 20,
				style = 0,
				},
			eyebrows = {
				opacity = 1,
				color = 54,
				style = 30,
				},
			makeUp = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			bodyBlemishes = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			blemishes = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			lipstick = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			blush = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			sunDamage = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			},
			faceFeatures = {
			nosePeakHigh = -0.3,
			eyeBrownHigh = 0,
			noseBoneTwist = -0.3,
			cheeksBoneHigh = -0.2,
			jawBoneWidth = 0.5,
			eyeBrownForward = 0,
			cheeksWidth = 0.5,
			chinHole = 1,
			noseBoneHigh = 0.1,
			nosePeakLowering = 0.1,
			cheeksBoneWidth = -1,
			noseWidth = -0.7,
			neckThickness = 1,
			nosePeakSize = -0.1,
			eyesOpening = 0.8,
			chinBoneSize = 0,
			lipsThickness = 0,
			jawBoneBackSize = -0.6,
			chinBoneLowering = 0,
			chinBoneLenght = 0,
			},
			components = {
			[1] = {
				texture = 0,
				component_id = 0,
				drawable = 0,
				},
			[2] = {
				texture = 0,
				component_id = 1,
				drawable = 0,
				},
			[3] = {
				texture = 0,
				component_id = 2,
				drawable = 64,
				},
			[4] = {
				texture = 0,
				component_id = 3,
				drawable = 12,
				},
			[5] = {
				texture = 0,
				component_id = 4,
				drawable = 1,
				},
			[6] = {
				texture = 0,
				component_id = 5,
				drawable = 0,
				},
			[7] = {
				texture = 0,
				component_id = 6,
				drawable = 157,
				},
			[8] = {
				texture = 0,
				component_id = 7,
				drawable = 0,
				},
			[9] = {
				texture = 3,
				component_id = 8,
				drawable = 88,
				},
			[10] = {
				texture = 0,
				component_id = 9,
				drawable = 0,
				},
			[11] = {
				texture = 0,
				component_id = 10,
				drawable = 0,
				},
			[12] = {
				texture = 0,
				component_id = 11,
				drawable = 0,
				},
			},
			hair = {
			color = 20,
			highlight = 20,
			style = 64,
			},
			headBlend = {
			shapeFirst = 45,
			skinSecond = 0,
			shapeSecond = 45,
			skinMix = 0,
			skinFirst = 7,
			shapeMix = 0.4,
			},
			eyeColor = 24,
		},
		['f'] = {
			props = {
			[1] = {
				texture = -1,
				drawable = -1,
				prop_id = 0,
				},
			[2] = {
				texture = -1,
				drawable = -1,
				prop_id = 1,
				},
			[3] = {
				texture = -1,
				drawable = -1,
				prop_id = 2,
				},
			[4] = {
				texture = -1,
				drawable = -1,
				prop_id = 6,
				},
			[5] = {
				texture = -1,
				drawable = -1,
				prop_id = 7,
				},
			},
			headBlend = {
			skinSecond = 6,
			skinMix = 0.6,
			shapeFirst = 33,
			shapeMix = 0.6,
			shapeSecond = 6,
			skinFirst = 33,
			},
			model = "mp_f_freemode_01",
			eyeColor = 8,
			faceFeatures = {
			nosePeakHigh = 0.4,
			chinBoneSize = 0,
			eyeBrownHigh = -0.5,
			noseBoneHigh = 0,
			jawBoneBackSize = 0,
			chinBoneLowering = -1,
			cheeksWidth = 0,
			neckThickness = -0.5,
			jawBoneWidth = 0,
			cheeksBoneWidth = 0,
			noseWidth = -1,
			nosePeakSize = 0.5,
			eyesOpening = -0.6,
			noseBoneTwist = 0,
			lipsThickness = 0,
			chinHole = 0,
			cheeksBoneHigh = 0,
			nosePeakLowering = 0,
			eyeBrownForward = -0.8,
			chinBoneLenght = 1,
			},
			components = {
			[1] = {
				texture = 0,
				component_id = 0,
				drawable = 0,
				},
			[2] = {
				texture = 0,
				component_id = 1,
				drawable = 0,
				},
			[3] = {
				texture = 3,
				component_id = 2,
				drawable = 3,
				},
			[4] = {
				texture = 0,
				component_id = 3,
				drawable = 3,
				},
			[5] = {
				texture = 2,
				component_id = 4,
				drawable = 8,
				},
			[6] = {
				texture = 0,
				component_id = 5,
				drawable = 0,
				},
			[7] = {
				texture = 3,
				component_id = 6,
				drawable = 19,
				},
			[8] = {
				texture = 0,
				component_id = 7,
				drawable = 85,
				},
			[9] = {
				texture = 5,
				component_id = 8,
				drawable = 111,
				},
			[10] = {
				texture = 0,
				component_id = 9,
				drawable = 0,
				},
			[11] = {
				texture = 0,
				component_id = 10,
				drawable = 0,
				},
			[12] = {
				texture = 2,
				component_id = 11,
				drawable = 25,
				},
			},
			hair = {
			style = 3,
			color = 34,
			highlight = 38,
			},
			headOverlays = {
			makeUp = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			blush = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			bodyBlemishes = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			lipstick = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			sunDamage = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			moleAndFreckles = {
				opacity = 0.8,
				color = 0,
				style = 12,
				},
			blemishes = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			eyebrows = {
				opacity = 0.7,
				color = 52,
				style = 32,
				},
			complexion = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			ageing = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			beard = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			chestHair = {
				opacity = 0,
				color = 0,
				style = 0,
				},
			},
			tattoos = {
			},
		}  
	},

	['fivem-appearance'] = {
		['m'] = {
			props = {
			[1] = {
				texture = -1,
				drawable = -1,
				prop_id = 0,
				},
			[2] = {
				texture = 0,
				drawable = 0,
				prop_id = 1,
				},
			[3] = {
				texture = -1,
				drawable = -1,
				prop_id = 2,
				},
			[4] = {
				texture = -1,
				drawable = -1,
				prop_id = 6,
				},
			[5] = {
				texture = -1,
				drawable = -1,
				prop_id = 7,
				},
			},
			headBlend = {
			skinSecond = 0,
			skinMix = 0.3,
			shapeFirst = 21,
			shapeMix = 0.4,
			shapeSecond = 0,
			skinFirst = 21,
			},
			model = "mp_m_freemode_01",
			eyeColor = 0,
			faceFeatures = {
			jawBoneWidth = -0.2,
			noseBoneTwist = -0.3,
			eyeBrownHigh = 0,
			noseBoneHigh = 0.1,
			jawBoneBackSize = -0.2,
			chinBoneLowering = 0,
			eyeBrownForward = 0,
			neckThickness = 0,
			nosePeakHigh = 0,
			nosePeakLowering = 0.1,
			lipsThickness = -0.4,
			nosePeakSize = -0.1,
			chinHole = 0,
			cheeksWidth = 0.5,
			chinBoneSize = 0,
			eyesOpening = 0,
			cheeksBoneHigh = -0.2,
			noseWidth = -0.5,
			cheeksBoneWidth = -1,
			chinBoneLenght = 0,
			},
			components = {
			[1] = {
				texture = 0,
				component_id = 0,
				drawable = 0,
				},
			[2] = {
				texture = 0,
				component_id = 1,
				drawable = 0,
				},
			[3] = {
				texture = 0,
				component_id = 2,
				drawable = 49,
				},
			[4] = {
				texture = 0,
				component_id = 3,
				drawable = 1,
				},
			[5] = {
				texture = 0,
				component_id = 4,
				drawable = 25,
				},
			[6] = {
				texture = 0,
				component_id = 5,
				drawable = 0,
				},
			[7] = {
				texture = 2,
				component_id = 6,
				drawable = 69,
				},
			[8] = {
				texture = 2,
				component_id = 7,
				drawable = 22,
				},
			[9] = {
				texture = 0,
				component_id = 8,
				drawable = 4,
				},
			[10] = {
				texture = 0,
				component_id = 9,
				drawable = 0,
				},
			[11] = {
				texture = 0,
				component_id = 10,
				drawable = 0,
				},
			[12] = {
				texture = 0,
				component_id = 11,
				drawable = 10,
				},
			},
			hair = {
			style = 49,
			color = 47,
			highlight = 29,
			},
			headOverlays = {
			makeUp = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			chestHair = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			bodyBlemishes = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			lipstick = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			sunDamage = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			moleAndFreckles = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			blemishes = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			blush = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			complexion = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			eyebrows = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			beard = {
				style = 11,
				color = 0,
				opacity = 1,
				},
			ageing = {
				style = 0,
				color = 0,
				opacity = 0,
				},
			},
			tattoos = {
			},
		},
		['f'] = {
			props = {
			   [1] = {
				  texture = -1,
				  drawable = -1,
				  prop_id = 0,
				},
			   [2] = {
				  texture = -1,
				  drawable = -1,
				  prop_id = 1,
				},
			   [3] = {
				  texture = -1,
				  drawable = -1,
				  prop_id = 2,
				},
			   [4] = {
				  texture = -1,
				  drawable = -1,
				  prop_id = 6,
				},
			   [5] = {
				  texture = -1,
				  drawable = -1,
				  prop_id = 7,
				},
			 },
			headBlend = {
			   skinSecond = 6,
			   skinMix = 0.6,
			   shapeFirst = 33,
			   shapeMix = 0.6,
			   shapeSecond = 6,
			   skinFirst = 33,
			 },
			model = "mp_f_freemode_01",
			eyeColor = 8,
			faceFeatures = {
			   nosePeakHigh = 0.4,
			   chinBoneSize = 0,
			   eyeBrownHigh = -0.5,
			   noseBoneHigh = 0,
			   jawBoneBackSize = 0,
			   chinBoneLowering = -1,
			   cheeksWidth = 0,
			   neckThickness = -0.5,
			   jawBoneWidth = 0,
			   cheeksBoneWidth = 0,
			   noseWidth = -1,
			   nosePeakSize = 0.5,
			   eyesOpening = -0.6,
			   noseBoneTwist = 0,
			   lipsThickness = 0,
			   chinHole = 0,
			   cheeksBoneHigh = 0,
			   nosePeakLowering = 0,
			   eyeBrownForward = -0.8,
			   chinBoneLenght = 1,
			 },
			components = {
			   [1] = {
				  texture = 0,
				  component_id = 0,
				  drawable = 0,
				},
			   [2] = {
				  texture = 0,
				  component_id = 1,
				  drawable = 0,
				},
			   [3] = {
				  texture = 3,
				  component_id = 2,
				  drawable = 3,
				},
			   [4] = {
				  texture = 0,
				  component_id = 3,
				  drawable = 3,
				},
			   [5] = {
				  texture = 2,
				  component_id = 4,
				  drawable = 8,
				},
			   [6] = {
				  texture = 0,
				  component_id = 5,
				  drawable = 0,
				},
			   [7] = {
				  texture = 3,
				  component_id = 6,
				  drawable = 19,
				},
			   [8] = {
				  texture = 0,
				  component_id = 7,
				  drawable = 85,
				},
			   [9] = {
				  texture = 5,
				  component_id = 8,
				  drawable = 111,
				},
			   [10] = {
				  texture = 0,
				  component_id = 9,
				  drawable = 0,
				},
			   [11] = {
				  texture = 0,
				  component_id = 10,
				  drawable = 0,
				},
			   [12] = {
				  texture = 2,
				  component_id = 11,
				  drawable = 25,
				},
			 },
			hair = {
			   style = 3,
			   color = 34,
			   highlight = 38,
			 },
			headOverlays = {
			   makeUp = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   blush = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   bodyBlemishes = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   lipstick = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   sunDamage = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   moleAndFreckles = {
				  opacity = 0.8,
				  color = 0,
				  style = 12,
				},
			   blemishes = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   eyebrows = {
				  opacity = 0.7,
				  color = 52,
				  style = 32,
				},
			   complexion = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   ageing = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   beard = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			   chestHair = {
				  opacity = 0,
				  color = 0,
				  style = 0,
				},
			 },
			tattoos = {
			 },
		}  
	},

	['default'] = {
		["m"] = {
			mom = 43,
			dad = 29,
			face_md_weight = 61,
			skin_md_weight = 27,
			nose_1 = -5,
			nose_2 = 6,
			nose_3 = 5,
			nose_4 = 8,
			nose_5 = 10,
			nose_6 = 0,
			cheeks_1 = 2,
			cheeks_2 = -10,
			cheeks_3 = 6,
			lip_thickness = -2,
			jaw_1 = 0,
			jaw_2 = 0,
			chin_1 = 0,
			chin_2 = 0,
			chin_13 = 0,
			chin_4 = 0,
			neck_thickness = 0,
			hair_1 = 76,
			hair_2 = 0,
			hair_color_1 = 61,
			hair_color_2 = 29,
			tshirt_1 = 4,
			tshirt_2 = 2,
			torso_1 = 23,
			torso_2 = 2,
			decals_1 = 0,
			decals_2 = 0,
			arms = 1,
			arms_2 = 0,
			pants_1 = 28,
			pants_2 = 3,
			shoes_1 = 70,
			shoes_2 = 2,
			mask_1 = 0,
			mask_2 = 0,
			bproof_1 = 0,
			bproof_2 = 0,
			chain_1 = 22,
			chain_2 = 2,
			helmet_1 = -1,
			helmet_2 = 0,
			glasses_1 = 0,
			glasses_2 = 0,
			watches_1 = -1,
			watches_2 = 0,
			bracelets_1 = -1,
			bracelets_2 = 0,
			bags_1 = 0,
			bags_2 = 0,
			eye_color = 0,
			eye_squint = 0,
			eyebrows_2 = 0,
			eyebrows_1 = 0,
			eyebrows_3 = 0,
			eyebrows_4 = 0,
			eyebrows_5 = 0,
			eyebrows_6 = 0,
			makeup_1 = 0,
			makeup_2 = 0,
			makeup_3 = 0,
			makeup_4 = 0,
			lipstick_1 = 0,
			lipstick_2 = 0,
			lipstick_3 = 0,
			lipstick_4 = 0,
			ears_1 = -1,
			ears_2 = 0,
			chest_1 = 0,
			chest_2 = 0,
			chest_3 = 0,
			bodyb_1 = -1,
			bodyb_2 = 0,
			bodyb_3 = -1,
			bodyb_4 = 0,
			age_1 = 0,
			age_2 = 0,
			blemishes_1 = 0,
			blemishes_2 = 0,
			blush_1 = 0,
			blush_2 = 0,
			blush_3 = 0,
			complexion_1 = 0,
			complexion_2 = 0,
			sun_1 = 0,
			sun_2 = 0,
			moles_1 = 0,
			moles_2 = 0,
			beard_1 = 11,
			beard_2 = 10,
			beard_3 = 0,
			beard_4 = 0
		},
		["f"] = {
			mom = 28,
			dad = 6,
			face_md_weight = 63,
			skin_md_weight = 60,
			nose_1 = -10,
			nose_2 = 4,
			nose_3 = 5,
			nose_4 = 0,
			nose_5 = 0,
			nose_6 = 0,
			cheeks_1 = 0,
			cheeks_2 = 0,
			cheeks_3 = 0,
			lip_thickness = 0,
			jaw_1 = 0,
			jaw_2 = 0,
			chin_1 = -10,
			chin_2 = 10,
			chin_13 = -10,
			chin_4 = 0,
			neck_thickness = -5,
			hair_1 = 43,
			hair_2 = 0,
			hair_color_1 = 29,
			hair_color_2 = 35,
			tshirt_1 = 111,
			tshirt_2 = 5,
			torso_1 = 25,
			torso_2 = 2,
			decals_1 = 0,
			decals_2 = 0,
			arms = 3,
			arms_2 = 0,
			pants_1 = 12,
			pants_2 = 2,
			shoes_1 = 20,
			shoes_2 = 10,
			mask_1 = 0,
			mask_2 = 0,
			bproof_1 = 0,
			bproof_2 = 0,
			chain_1 = 85,
			chain_2 = 0,
			helmet_1 = -1,
			helmet_2 = 0,
			glasses_1 = 33,
			glasses_2 = 12,
			watches_1 = -1,
			watches_2 = 0,
			bracelets_1 = -1,
			bracelets_2 = 0,
			bags_1 = 0,
			bags_2 = 0,
			eye_color = 8,
			eye_squint = -6,
			eyebrows_2 = 7,
			eyebrows_1 = 32,
			eyebrows_3 = 52,
			eyebrows_4 = 9,
			eyebrows_5 = -5,
			eyebrows_6 = -8,
			makeup_1 = 0,
			makeup_2 = 0,
			makeup_3 = 0,
			makeup_4 = 0,
			lipstick_1 = 0,
			lipstick_2 = 0,
			lipstick_3 = 0,
			lipstick_4 = 0,
			ears_1 = -1,
			ears_2 = 0,
			chest_1 = 0,
			chest_2 = 0,
			chest_3 = 0,
			bodyb_1 = -1,
			bodyb_2 = 0,
			bodyb_3 = -1,
			bodyb_4 = 0,
			age_1 = 0,
			age_2 = 0,
			blemishes_1 = 0,
			blemishes_2 = 0,
			blush_1 = 0,
			blush_2 = 0,
			blush_3 = 0,
			complexion_1 = 0,
			complexion_2 = 0,
			sun_1 = 0,
			sun_2 = 0,
			moles_1 = 12,
			moles_2 = 8,
			beard_1 = 0,
			beard_2 = 0,
			beard_3 = 0,
			beard_4 = 0
		}
	},
	['codem-appearance'] = {
		["m"] = {
			mom = 43,
			dad = 29,
			face_md_weight = 61,
			skin_md_weight = 27,
			nose_1 = -5,
			nose_2 = 6,
			nose_3 = 5,
			nose_4 = 8,
			nose_5 = 10,
			nose_6 = 0,
			cheeks_1 = 2,
			cheeks_2 = -10,
			cheeks_3 = 6,
			lip_thickness = -2,
			jaw_1 = 0,
			jaw_2 = 0,
			chin_1 = 0,
			chin_2 = 0,
			chin_13 = 0,
			chin_4 = 0,
			neck_thickness = 0,
			hair_1 = 76,
			hair_2 = 0,
			hair_color_1 = 61,
			hair_color_2 = 29,
			tshirt_1 = 4,
			tshirt_2 = 2,
			torso_1 = 23,
			torso_2 = 2,
			decals_1 = 0,
			decals_2 = 0,
			arms = 1,
			arms_2 = 0,
			pants_1 = 28,
			pants_2 = 3,
			shoes_1 = 70,
			shoes_2 = 2,
			mask_1 = 0,
			mask_2 = 0,
			bproof_1 = 0,
			bproof_2 = 0,
			chain_1 = 22,
			chain_2 = 2,
			helmet_1 = -1,
			helmet_2 = 0,
			glasses_1 = 0,
			glasses_2 = 0,
			watches_1 = -1,
			watches_2 = 0,
			bracelets_1 = -1,
			bracelets_2 = 0,
			bags_1 = 0,
			bags_2 = 0,
			eye_color = 0,
			eye_squint = 0,
			eyebrows_2 = 0,
			eyebrows_1 = 0,
			eyebrows_3 = 0,
			eyebrows_4 = 0,
			eyebrows_5 = 0,
			eyebrows_6 = 0,
			makeup_1 = 0,
			makeup_2 = 0,
			makeup_3 = 0,
			makeup_4 = 0,
			lipstick_1 = 0,
			lipstick_2 = 0,
			lipstick_3 = 0,
			lipstick_4 = 0,
			ears_1 = -1,
			ears_2 = 0,
			chest_1 = 0,
			chest_2 = 0,
			chest_3 = 0,
			bodyb_1 = -1,
			bodyb_2 = 0,
			bodyb_3 = -1,
			bodyb_4 = 0,
			age_1 = 0,
			age_2 = 0,
			blemishes_1 = 0,
			blemishes_2 = 0,
			blush_1 = 0,
			blush_2 = 0,
			blush_3 = 0,
			complexion_1 = 0,
			complexion_2 = 0,
			sun_1 = 0,
			sun_2 = 0,
			moles_1 = 0,
			moles_2 = 0,
			beard_1 = 11,
			beard_2 = 10,
			beard_3 = 0,
			beard_4 = 0
		},
		["f"] = {
			mom = 28,
			dad = 6,
			face_md_weight = 63,
			skin_md_weight = 60,
			nose_1 = -10,
			nose_2 = 4,
			nose_3 = 5,
			nose_4 = 0,
			nose_5 = 0,
			nose_6 = 0,
			cheeks_1 = 0,
			cheeks_2 = 0,
			cheeks_3 = 0,
			lip_thickness = 0,
			jaw_1 = 0,
			jaw_2 = 0,
			chin_1 = -10,
			chin_2 = 10,
			chin_13 = -10,
			chin_4 = 0,
			neck_thickness = -5,
			hair_1 = 43,
			hair_2 = 0,
			hair_color_1 = 29,
			hair_color_2 = 35,
			tshirt_1 = 111,
			tshirt_2 = 5,
			torso_1 = 25,
			torso_2 = 2,
			decals_1 = 0,
			decals_2 = 0,
			arms = 3,
			arms_2 = 0,
			pants_1 = 12,
			pants_2 = 2,
			shoes_1 = 20,
			shoes_2 = 10,
			mask_1 = 0,
			mask_2 = 0,
			bproof_1 = 0,
			bproof_2 = 0,
			chain_1 = 85,
			chain_2 = 0,
			helmet_1 = -1,
			helmet_2 = 0,
			glasses_1 = 33,
			glasses_2 = 12,
			watches_1 = -1,
			watches_2 = 0,
			bracelets_1 = -1,
			bracelets_2 = 0,
			bags_1 = 0,
			bags_2 = 0,
			eye_color = 8,
			eye_squint = -6,
			eyebrows_2 = 7,
			eyebrows_1 = 32,
			eyebrows_3 = 52,
			eyebrows_4 = 9,
			eyebrows_5 = -5,
			eyebrows_6 = -8,
			makeup_1 = 0,
			makeup_2 = 0,
			makeup_3 = 0,
			makeup_4 = 0,
			lipstick_1 = 0,
			lipstick_2 = 0,
			lipstick_3 = 0,
			lipstick_4 = 0,
			ears_1 = -1,
			ears_2 = 0,
			chest_1 = 0,
			chest_2 = 0,
			chest_3 = 0,
			bodyb_1 = -1,
			bodyb_2 = 0,
			bodyb_3 = -1,
			bodyb_4 = 0,
			age_1 = 0,
			age_2 = 0,
			blemishes_1 = 0,
			blemishes_2 = 0,
			blush_1 = 0,
			blush_2 = 0,
			blush_3 = 0,
			complexion_1 = 0,
			complexion_2 = 0,
			sun_1 = 0,
			sun_2 = 0,
			moles_1 = 12,
			moles_2 = 8,
			beard_1 = 0,
			beard_2 = 0,
			beard_3 = 0,
			beard_4 = 0
		}
	}
	  
}