const store = Vuex.createStore({
  state: {},
  mutations: {},
  actions: {},
});

let audioPlayer = null;

const app = Vue.createApp({
  data: () => ({
    show: false,
    registerPage: false,
    charactersData: "",
    animleftContainer: false,
    currentCharacterData: false,
    slotNumber: 0,
    tebexSlotPopup: false,
    selectedPopup: [],
    steamName: "",
    steamProfile: "",
    steamID: "",
    nameValue: "",
    surnameValue: "",
    birthdayValue: null,
    heightValue: "",
    genderValue: "",
    nationalityValue: "",
    cid: 0,
    currentCid: "",
    selectedCid: "",
    tbxID: "",
    viewedCharacters: [],
    viewedCharacters2: [],
    deletePopup: false,
    dataLoaded: false,
    isError: false,
    errorMessage: "",
    forbiddenSymbols: [
      "!",
      "@",
      "#",
      "$",
      "%",
      "^",
      "&",
      "*",
      "(",
      ")",
      "+",
      "=",
    ],
    displayMessage: "",
    Locales: "",
    dateFormat: "",
    serverLogo: "",
    CanDelete: null,
    isError: false,
    loadingContainer: false,
  }),

  methods: {
    playClickSound() {
      clicksound("click.mp3");
    },
    onNumericInput() {
      this.numericValue = this.numericValue.replace(/[^0-9]/g, "");
    },
    shouldShowCharacter(slotId) {
      return (
        !this.viewedCharacters.includes(slotId) &&
        this.getCharacter(slotId, true)
      );
    },
    getCharacter(slotId, bool) {
      setTimeout(() => {
        $(".loading-container").fadeOut(300);
        this.loadingContainer = false;
      }, 1500);
      const character = this.charactersData.find(
        (info) => parseInt(info.identifier[4]) === slotId
      );

      if (character) {
        return bool ? character : character.job;
      }
      return null;
    },
    handleCharacterClick(slotId) {
      const character = this.getCharacter(slotId, true);
      if (character) {
        this.currentCharacterDataValue(character, slotId);
        this.viewedCharacters.push(slotId);
      }
    },
    setGender(value) {
      this.genderValue = value;
    },
    joinGame() {
      postNUI("Play", {
        charData: this.currentCharacterData,
      });
      this.show = false;
      this.currentCharacterData = false;
      this.selectedPopup = {};
    },
    checkData() {
      if (this.dataLoaded == false) {
        postNUI("loadagain");
        this.dataLoaded = true;
      }
    },
    openRegister(slot, tebexSlot) {
      if (!this.loadingContainer) {
        this.selectedCid = slot;

        if (tebexSlot) {
          this.currentCharacterData = false;
          this.selectedPopup = {};
          this.tebexSlotPopup = true;
          this.registerPage = false;
        } else {
          (this.show = false), (this.registerPage = true);
          this.currentCharacterData = false;
          this.selectedPopup = {};
          postNUI("SetAnimations", {
            toggle: false,
          });
        }
        postNUI("ChangeCam", {});
      }
    },
    checkTebex() {
      postNUI("checkTebex", {
        tbxid: this.tbxID,
        slotno: this.selectedCid,
      });
    },
    createCharacter() {
      for (const value of [this.nameValue, this.surnameValue]) {
        if (!value || value.trim() === "") {
          this.displayMessage = this.Locales["registerError"];
          this.isError = true;
          return;
        }

        for (const symbol of this.forbiddenSymbols) {
          if (value.includes(symbol)) {
            this.displayMessage = this.Locales["registerError"];
            this.isError = true;
            return;
          }
        }
      }

      if (
        this.genderValue.toString() !== "0" &&
        this.genderValue.toString() !== "1"
      ) {
        this.displayMessage = this.Locales["registerError"];
        this.isError = true;
        return;
      }

      if (
        this.heightValue.toString() < "0" ||
        this.heightValue.toString() > "300"
      ) {
        this.displayMessage = this.Locales["registerError"];
        this.isError = true;
        return;
      }

      const namePattern = /^[A-Z][a-z]{2,}$/;
      if (
        !namePattern.test(this.nameValue) ||
        !namePattern.test(this.surnameValue)
      ) {
        this.displayMessage = this.Locales["registerError"];
      } else {
        const dateValue = new Date(this.birthdayValue);
        const year = dateValue.getFullYear();
        const month = dateValue.getMonth() + 1;

        const isValidBirthday =
          year <= 2023 &&
          year >= 1900 &&
          year.toString().length === 4 &&
          month >= 1 &&
          month <= 12 &&
          this.birthdayValue.split("-")[2] <=
            new Date(year, month, 0).getDate() &&
          new Date().getFullYear() - year <= 1000;

        if (!isValidBirthday) {
          this.displayMessage = this.Locales["registerError"];
        } else {
          this.displayMessage = this.Locales["registerVerify"];
          this.show = false;
          this.registerPage = false;
          this.charactersData.id += 1;

          postNUI("createChar", {
            firstname: this.nameValue,
            lastname: this.surnameValue,
            nationality: this.nationalityValue,
            dateofbirth: this.birthdayValue,
            height: this.heightValue,
            gender: this.genderValue,
            cid: this.selectedCid,
          });
          this.nameValue = "";
          this.surnameValue = "";
          this.heightValue = "";
          this.genderValue = "";
          this.nationalityValue = "";
          this.birthdayValue = "";
          this.displayMessage = "";
          this.isError = false;
          this.currentCharacterData = false;
        }
      }
    },
    openDeletePopUp() {
      if (this.CanDelete) {
        this.deletePopup = true;
      }
    },
    cancelCreate() {
      if (this.registerPage) {
        this.registerPage = false;
        this.show = true;
        this.nameValue = "";
        this.surnameValue = "";
        this.heightValue = "";
        this.genderValue = "";
        this.nationalityValue = "";
        this.birthdayValue = "";
        this.displayMessage = "";
        this.isError = false;
        this.currentCharacterData = false;
      } else if (this.tebexSlotPopup) {
        this.tebexSlotPopup = false;
        this.show = true;
        this.tbxID = "";
      }
    },
    cancelDelete() {
      this.deletePopup = false;
    },
    deleteCharacter() {
      const charactersDatas = this.charactersData.find(
        (item) => item.identifier == this.currentCharacterData.identifier
      );
      postNUI("DeleteCharacter", {
        charid: parseInt(this.currentCharacterData.identifier[4]),
        identifier: this.currentCharacterData.identifier,
      });
      this.charactersData.splice(
        this.charactersData.indexOf(charactersDatas),
        1
      );
      this.currentCharacterData = false;
      this.deletePopup = false;
    },
    handleKeyUp: function (e) {
      if (e.key == "Escape") {
        this.cancelCreate();
      }
    },
    currentCharacterDataValue(val, slotNumber, bool) {
      if (!this.loadingContainer) {
        const character = this.getCharacter(val, true);

        if (character && !this.viewedCharacters.includes(val)) {
          this.viewedCharacters.push(val);
        }

        if (val === this.currentCharacterData) {
          this.currentCharacterData = false;
          this.selectedPopup = {};
        } else {
          this.currentCharacterData = val;
          this.selectedPopup = {};
          this.selectedPopup[slotNumber] = true;

          postNUI("SetAnimations", {
            charData: this.currentCharacterData,
            toggle: true,
          });
        }

        if (bool && !val === this.currentCharacterData) {
          postNUI("ChangeCam", {});
          this.currentCharacterData = false;
          this.selectedPopup = {};
        }
      }
    },
  },
  computed: {
    formattedAge() {
      const separators = ["-", "/", " "];
      let separator = null;

      for (const sep of separators) {
        if (this.currentCharacterData.dateofbirth.includes(sep)) {
          separator = sep;
          break;
        }
      }

      if (!separator) {
        console.error("Invalid date format");
        return "";
      }

      const birthdateArr =
        this.currentCharacterData.dateofbirth.split(separator);
      let day, month, year;

      if (birthdateArr[0].length === 4) {
        year = birthdateArr[0];
        month = birthdateArr[1] - 1;
        day = birthdateArr[2];
      } else {
        day = birthdateArr[0];
        month = birthdateArr[1] - 1;
        year = birthdateArr[2];
      }

      const birthdateObj = new Date(year, month, day);
      const now = new Date();

      const ageInMilliseconds = now - birthdateObj;
      const ageInYears = ageInMilliseconds / (365 * 24 * 60 * 60 * 1000);

      const formattedBirthdate = birthdateObj.toLocaleDateString(
        this.dateFormat,
        {
          day: "numeric",
          month: "long",
          year: "numeric",
        }
      );

      this.age = formattedBirthdate;

      return `${Math.floor(ageInYears)} ${
        this.Locales["ageTitle"]
      } - ${formattedBirthdate}`;
    },
  },

  watch: {},

  beforeDestroy() {},
  mounted() {
    window.addEventListener("load", (event) => {
      this.checkData();
    });
    window.addEventListener("keyup", this.keyHandler);
    window.addEventListener("message", (event) => {
      switch (event.data.message) {

        case "CHECK_NUI":
          postNUI("loaded", true);
        break;
        case "SetChars":
          $(".loading-container").fadeIn(1000);
          this.loadingContainer = true;
          this.show = true;
          this.nameValue = "";
          this.surnameValue = "";
          this.heightValue = "";
          this.genderValue = "";
          this.nationalityValue = "";
          this.birthdayValue = "";
          this.currentCid = event.data.charData.length;
          this.charactersData = event.data.charData;
          this.Locales = event.data.Locales;
          this.slotNumber = event.data.Slots;
          this.CanDelete = event.data.CanDelete;
          this.serverLogo = event.data.serverLogo;
          this.dateFormat = event.data.dateFormat;
          this.show = true;
        break;
        case "SetSteamInfos":
          this.steamName = event.data.name;
          this.steamProfile = event.data.profilephoto;
          this.steamID = event.data.id;
        break;
        case "UnlockTebexSlot":
          this.unlockTebex = event.data.slotno;
          this.tebexSlotPopup = false;
          this.slotNumber.forEach((item) => {
            if (item.id === this.unlockTebex) {
              item.tebex = false;
            }
          });
        break;
          default:
            break;
      }
    });
    setTimeout(() => {
      this.animleftContainer = true;
    }, 2000);
    window.addEventListener("keyup", this.handleKeyUp);
  },

  destroyed() {
    window.removeEventListener("keyup", this.handleKeyUp);
  },
});

app.use(store).mount("#app");

const resourceName = window.GetParentResourceName
  ? window.GetParentResourceName()
  : "mMulticharacter";

window.postNUI = async (name, data) => {
  try {
    const response = await fetch(`https://${resourceName}/${name}`, {
      method: "POST",
      mode: "cors",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
      redirect: "follow",
      referrerPolicy: "no-referrer",
      body: JSON.stringify(data),
    });
    return !response.ok ? null : response.json();
  } catch (error) {
    // console.log(error)
  }
};

function clicksound(val) {
  let audioPath = `./${val}`;
  
  if (audioPlayer && audioPlayer.playing()) {
      audioPlayer.stop();
  } else {
      audioPlayer = new Howl({
          src: [audioPath]
      });
      audioPlayer.volume(0.4);
      audioPlayer.play();
  }
}