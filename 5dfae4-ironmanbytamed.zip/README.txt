================================================================
  IRON MAN  for GTA V
  a TAMED MODS production
  Developed by Tamed Mods
  Support development: https://www.patreon.com/Tamedmods
================================================================

INSTALLATION
  1. Install ScriptHookV (by Alexander Blade) if you don't have it.
  2. Copy IronMan.asi   -> your GTA V folder (next to GTA5.exe)
  3. Copy IronMan.ini   -> GTA V folder (next to GTA5.exe)
  4.Copy reticle.png  -> GTA V folder (the HUD targeting reticle)
  5. Copy the IronManSFX folder -> GTA V folder ( for voice/SFX)

  IMPORTANT: the config file must be named exactly "IronMan.ini".
  If your browser saved it as IronMan(1).ini or IronMan_2.ini, rename it.
  If the mod can't find it, an on-screen warning appears and it falls back
  to built-in defaults.

CONTROLS
  F5              suit up / down
  SPACE (press)   fly instantly
  SPACE (hold)    keep climbing
  SPACE (tap while flying)  land
  LCTRL           descend
  LSHIFT          boost
  W A S D         steer while flying
  E               repulsor beam (charge, fires, recharges)
  Q (hold)        unibeam
  R               homing missiles
  F               pulse blast (shockwave + EMP)
  G               ground slam
  X               hero landing (from the air) / slam on the ground
  C               combat mode: super-strength melee
  V               grab a ped or vehicle -> LMB to throw it
  B               shoulder machine-gun toggle
  RMB             lock on / off
  T               cycle locked target
  LMB             quick repulsor shots (6-shot burst, then recharges)
  F7              write IronMan_diag.txt (for troubleshooting)

ARC REACTOR
  Flight and weapons share one power pool. It drains while you fly and
  fire, and recharges when systems rest. JARVIS warns you when it's low.

TUNING
  Everything is configurable in IronMan.ini - speeds, forces, colours,
  cooldowns, key bindings, energy costs and animation sets.

CREDITS
  Development: Tamed Mods
  ScriptHookV: Alexander Blade
  Native reference: alloc8or's native DB

  Iron Man and related characters are trademarks of Marvel. This is a
  free, non-commercial fan project and is not affiliated with or endorsed
  by Marvel or Rockstar Games.

  If you enjoy the mod, support future development:
  https://www.patreon.com/Tamedmods
